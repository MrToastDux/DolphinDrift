# Dolphin Drift

A browser runner set in futuristic Neo Kingston, with animated sea creatures, golden records, and an original synthesized reggae soundtrack. All artwork is drawn in Canvas; no API keys or package installation are required.

## Run locally

Requires Node.js 20 or newer:

```sh
npm start
```

Open [http://localhost:5173](http://localhost:5173). In VS Code, **F5** starts the server and opens the game. Refresh the page after changing source files.

## Choose a mode

| Mode | How it plays |
| --- | --- |
| Endless | Dodge obstacles, collect records, and chase your best distance as the pace increases. |
| Daily route | A repeatable course based on your local calendar date, with a separate daily score. Uses Dub and classic rules. |
| Island Tour | A 2,250 m obstacle course through three districts. Checkpoints award 60, 90, and 150 banked records. |
| Story | Six connected chapters with objectives, dialogue, patrol enemies, sonic weapons, and bosses. |

**Bosses, enemies, shooting, and Tidal blast are exclusive to Story.** The other modes focus on running, collecting records, and avoiding obstacles. Zen, 90s Sprint, and Hardcore have been removed. Existing career progress, purchases, character unlocks, and historical run data are retained.

## Controls

| Action | Keyboard | Touch |
| --- | --- | --- |
| Change lanes | Left / Right or A / D | Swipe left / right |
| Jump | Up, W, or Space | Swipe up or tap the track |
| Roll | Down or S | Swipe down |
| Character ability | C | Ability button |
| Dub dash | E | Dash button |
| Buy a surfboard flight | B | Surfboard button |
| Fire sonic weapon — Story only | Q | Fire button |
| Tidal blast — Story only | X | Tidal blast button |
| Pause / resume | Escape or P | Pause button |
| Retry after a crash | R | Retry button |
| Full screen | F | Logbook → Full screen |

Optional movement buttons are available in the Logbook. Switching away from the game pauses the run, and all gameplay timers freeze while paused.

## Running and progression

- Jump over coral, crates and buoys; roll under gates; steer around carts and trams. Super jump can clear taller obstacles. Every generated row has a clear lane marked by records.
- Speed starts at 12 m/s and increases by 0.18 m/s each active second. Later rows use speed-scaled spacing.
- Spend **200 records from the current run** for a **20-second surfboard flight**. Steer through sky records while flying above ground hazards.
- Magnet attracts records for 10 seconds; Shield absorbs one hit within 12 seconds; Ghost passes through obstacles for 6 seconds; Super jump lasts 12 seconds. Shop upgrades can extend durations.
- Collect **25 records** to charge a free three-second Dub dash, which protects you and attracts records.
- Keep collecting within six seconds to build a combo. Every 12 records increases the score multiplier, up to ×5. Clean jumps and rolls build stunt chains; close dodges award bonus points.
- After a crash, **75 run records** buy one revive. Completed routes and failed chapter objectives cannot be revived.
- Finishing a run or returning home banks records, XP, mission rewards, and contract progress. Reviving recalculates that run without counting it twice.
- The shop offers skins, hats, boards, trails, duration upgrades, and starter supplies. **Try on** previews cosmetics before purchase.
- The Logbook contains achievements, career stats, contracts, recent runs, mode records, graphics preferences, audio sliders, reduced effects, touch controls, and postcard downloads.
- Save data stays in this browser. The game remains playable when storage is unavailable. Debug pages use an isolated profile and do not overwrite normal progress.

## Story: Bring back the beat

Choose **Story → Open island map**. Each chapter has a briefing, an in-run transmission, a required objective, and an ending. Complete the objective and reach the exit to unlock the next chapter. First-clear rewards pay once; replays still earn ordinary run rewards and can improve chapter scores.

| Chapter | Objective | First-clear reward |
| --- | --- | --- |
| The missing beat | Collect 20 records; reach 450 m | Inky + 100 records |
| Market takeover | Defeat 5 patrols; reach 600 m | Reef chorus + 150 records |
| Jailbreak at the docks | Collect 3 rescue rings; reach 700 m | Riff + 200 records |
| Break the bass line | Defeat Clawbreaker; reach 850 m | Bass lance + 250 records |
| Wings over Kingston | Defeat Scarlet Manta; reach 950 m | Shelly + 300 records |
| The last frequency | Defeat Overlord Static; reach 1,200 m | Island liberated + 500 records |

## Your crew

Choose a runner from the title screen or the island map. Unlocks come from Story and can also be used in Endless and Island Tour. Daily always uses Dub.

| Runner | Ability on C | Cooldown |
| --- | --- | --- |
| Dub, dolphin | Attract records for four seconds and gain five dash charge. | 14 seconds |
| Inky, octopus | Sweep up nearby ground records and launch a protected vault. In Story, grapple the nearest patrol within 45 m. | 12 seconds |
| Riff, shark | Smash ground hazards for three seconds, including patrols in Story. | 16 seconds |
| Shelly, turtle | Block hazards for five seconds. In Story, reflect incoming enemy fire. | 18 seconds |

Wardrobe skins and hats dress Dub; boards and trails work for every character.

## Story combat

Patrol drones, sentries, and armored brutes appear between bosses. Dodge them, jump over them, or use **Q / Fire**. Sentries show a warning beam before firing at your locked position.

- **Sonic pulse:** fast shots seek the nearest enemy.
- **Reef chorus:** hit up to three enemies across the track.
- **Bass lance:** pierce enemies in the target lane for three damage. During a boss fight, spend two energy to deal two armor damage.
- **Tidal blast:** records and patrol defeats charge a special attack. At 100%, press X to clear nearby enemies and hostile shots and deal three boss damage.

Boss shots track your position during the warning, then lock when fired. Move after the lock, jump, or roll. Firing in the mint impact window deflects the volley, refunds the shot, and awards a score bonus. Boss energy recharges every 3.5 active seconds, up to three; diamonds add energy sooner.

Bosses enter overdrive at half armor or late in the encounter. Break every armor plate before the chapter exit. A knockout awards 100 banked records, plus 50 for a flawless fight. The final boss, Overlord Static, has ten armor plates and cycles between cannonballs, missiles, and plasma fans.

## Development

`src/game.js` contains the rendering-independent simulation. `src/renderer.js`, `src/dolphin.js`, and `src/bosses.js` draw the world and characters. Campaign definitions, combat logic, and map UI live in `src/adventure.js`, `src/combat.js`, and `src/adventure-ui.js`. `src/progression.js` validates and saves profiles.

Use `npm test` for the simulation and progression suite, and `npm run check` for JavaScript syntax validation. `test/polish.test.js` covers generated Story objectives, rescue chapter completion, flight endpoints, and combat state regressions.

With the local server running, open [the polish regression checks](http://localhost:5173/test/polish-smoke.html) for real-control, save/revive, touch, and responsive-layout tests, or [the feature checks](http://localhost:5173/test/feature-smoke.html) for daily-route and progression integration tests. Both use isolated debug profiles. Other historical browser harnesses under `test/` may refer to the earlier mode lineup.
