// 50% more encounters per metre / second than the previous balance.
// Keep movement, hitboxes and individual shot warning times predictable.
export const DIFFICULTY_PRESSURE = 1.5;
