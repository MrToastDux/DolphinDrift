import { SHOP_ITEMS, findItem, itemPrice } from './catalog.js';
import { purchase } from './progression.js';

export function createShop({ getProfile, setProfile, game, onEquip, onPreview }) {
  const $ = id => document.getElementById(id);
  let category = 'skin';
  const names = {skin:'Skins',board:'Boards',trail:'Trails',hat:'Hats',upgrade:'Upgrades',supply:'Supplies'};
  function render() {
    const profile = getProfile(), shop = profile.shop, allowed = game.state === 'ready';
    $('shop-wallet').textContent = profile.wallet.toLocaleString();
    $('shop-availability').textContent = allowed ? 'Buy with banked records. Every item stays in this browser.' : 'Browsing only during a run. Return to the island to buy or equip.';
    $('shop-reset').disabled = !allowed;
    $('shop-tabs').replaceChildren(...Object.entries(names).map(([id,name]) => {
      const button=document.createElement('button');button.textContent=name;button.setAttribute('aria-pressed',String(category===id));
      button.addEventListener('click',()=>{category=id;render();});return button;
    }));
    $('shop-items').replaceChildren(...SHOP_ITEMS.filter(item=>item.category===category).map(item=>{
      const card=document.createElement('article');card.className='shop-item';
      const art=document.createElement('div');art.className=`item-art art-${category}`;art.style.setProperty('--item-color',item.color || '#d0c795');art.setAttribute('aria-hidden','true');
      art.textContent={skin:'◕',board:'∿',trail:'✧',hat:'♛',upgrade:'↑',supply:'◉'}[category];
      const title=document.createElement('h3');title.textContent=item.name;
      const description=document.createElement('p');description.textContent=item.description;
      const action=document.createElement('button');
      const owned=shop.owned.includes(item.id),level=shop.upgrades[item.id]||0,stock=shop.supplies[item.id]||0;
      const equipped=category==='skin'?profile.options.style===item.id:shop.equipped[category]===item.id;
      const max=category==='upgrade' && level===item.max || category==='supply' && stock===9;
      const price=itemPrice(item,shop);
      const detail=document.createElement('small');detail.textContent=category==='upgrade'?`Level ${level} / ${item.max}`:category==='supply'?`${stock} in your bag`:owned?'Owned':'Permanent unlock';
      action.textContent=owned?equipped?'Equipped':'Equip':max?'Maxed':`Buy · ${price} ◉`;
      action.disabled=!allowed || max || owned && equipped || !owned && profile.wallet<price;
      action.setAttribute('aria-label',`${action.textContent} ${item.name}`);
      action.addEventListener('click',()=>{
        if(game.state!=='ready')return;
        if(owned){
          const next=getProfile();
          if(category==='skin')next.options.style=item.id;else next.shop.equipped[category]=item.id;
          setProfile(next);onEquip();$('shop-status').textContent=`${item.name} equipped.`;
        }else{
          const result=purchase(getProfile(),item.id);
          if(result.ok)setProfile(result.profile);
          $('shop-status').textContent=result.message;
        }
        render();
        const index=SHOP_ITEMS.filter(entry=>entry.category===category).findIndex(entry=>entry.id===item.id);
        $('shop-items').children[index]?.querySelector('button:not(:disabled)')?.focus({preventScroll:true});
      });
      card.append(art,title,description,detail);
      if (!['upgrade','supply'].includes(category) && onPreview) {
        const preview=document.createElement('button');preview.className='try-on';preview.textContent='Try on';
        preview.setAttribute('aria-label',`Try on ${item.name}`);
        preview.addEventListener('click',()=>{onPreview(item);$('shop-status').textContent=`Previewing ${item.name}. Your equipped items are unchanged.`;});
        card.append(preview);
      }
      card.append(action);return card;
    }));
    const looks=[findItem(profile.options.style)?.name || profile.options.style,...Object.values(shop.equipped).filter(id=>id!=='default').map(id=>findItem(id)?.name)];
    $('equipped-summary').textContent=looks.join(' · ');
  }
  $('shop-reset').addEventListener('click',()=>{
    if(game.state!=='ready')return;
    const profile=getProfile();profile.shop.equipped={board:'default',trail:'default',hat:'default'};profile.options.style='classic';
    setProfile(profile);onEquip();render();$('shop-status').textContent='Original look equipped. Your purchases are still owned.';
  });
  return { render };
}
