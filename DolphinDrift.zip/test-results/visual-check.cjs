const {chromium}=require('C:/Users/trist/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:"msedge"});
 const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:1,isMobile:true,hasTouch:true});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:5173/?debug');await page.waitForFunction(()=>window.__drift);
 await page.locator('#mode-tour').click();await page.locator('#start').click();
 for(let i=0;i<3;i++){
  await page.evaluate(i=>{const {game:g,renderer:r}=window.__drift;g.state='playing';g.distance=i*750+575;g.objects=[];g._nextRow=g.distance+24;g._fillTrack();g._updateBoss(0);g.speed=24;g.update=()=>{};r.camera=1;r.time=1.6;document.getElementById('overlay').classList.add('hidden');},i);
  await page.waitForTimeout(650);
  await page.evaluate(()=>{document.getElementById('overlay').classList.add('hidden');window.__drift.renderer.draw(window.__drift.game,0,0)});
  await page.screenshot({path:`test-results/mobile-boss-${i}.png`});
 }
 console.log('errors',errors);
 console.log(await page.evaluate(()=>Object.fromEntries(['world','tour-status','counter'].map(id=>{const r=document.getElementById(id).getBoundingClientRect();return[id,{x:r.x,y:r.y,width:r.width,height:r.height}]}))));
 await page.setViewportSize({width:1440,height:900});await page.waitForTimeout(200);await page.evaluate(()=>document.getElementById('overlay').classList.add('hidden'));await page.screenshot({path:'test-results/desktop-boss.png'});
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});

