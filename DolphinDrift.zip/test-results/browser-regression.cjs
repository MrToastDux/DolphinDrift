const {chromium}=require('C:/Users/trist/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'msedge'});
 const page=await browser.newPage({viewport:{width:1280,height:900},hasTouch:true,isMobile:true});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:5173/test/boss-shop-smoke.html');
 await page.waitForFunction(()=>/checks passed|FAIL/.test(document.getElementById('status').textContent),null,{timeout:30000});
 console.log(await page.locator('#status').innerText());assert.match(await page.locator('#status').innerText(),/5 checks passed/);
 await page.goto('http://127.0.0.1:5173/?debug');await page.waitForFunction(()=>window.__drift);
 await page.locator('#mode-tour').click();await page.locator('#start').click();
 await page.evaluate(()=>{const {game:g,profile:p}=window.__drift;g.distance=2100;g.objects=[];g._nextRow=Infinity;g._updateBoss(0);g.update=()=>{};p.options.touchControls=true;g.powerups={magnet:5,shield:5,ghost:5,spring:5};});
 for(const [width,height] of [[320,568],[360,640],[390,844],[430,932],[844,390],[1440,900]]){
   await page.setViewportSize({width,height});await page.waitForTimeout(250);
   const layout=await page.evaluate(()=>{
    const r=el=>{const b=el.getBoundingClientRect();return{x:b.x,y:b.y,w:b.width,h:b.height,right:b.right,bottom:b.bottom}};
    const shell=r(document.querySelector('.game-shell')),hud=r(document.querySelector('.hud')),tour=r(document.getElementById('tour-status'));
    const buttons=['counter','dash','surfboard'].map(id=>({id,...r(document.getElementById(id))})).concat([...document.querySelectorAll('#touch-controls button')].map(el=>({id:el.getAttribute('aria-label'),...r(el)})));
    return{shell,hud,tour,buttons,scrollWidth:document.documentElement.scrollWidth};
   });
   assert.ok(layout.scrollWidth<=width,`horizontal overflow ${width}`);
   assert.ok(layout.shell.bottom<=height+1,`play area overflows ${width}`);
   for(const b of layout.buttons){assert.ok(b.x>=0&&b.right<=width&&b.bottom<=height,`${b.id} outside ${width}`);assert.ok(b.w>=36&&b.h>=36,`${b.id} too small at ${width}`)}
   const overlap=(a,b)=>Math.min(a.right,b.right)>Math.max(a.x,b.x)+1&&Math.min(a.bottom,b.bottom)>Math.max(a.y,b.y)+1;
   for(let i=0;i<layout.buttons.length;i++)for(let j=i+1;j<layout.buttons.length;j++)assert.ok(!overlap(layout.buttons[i],layout.buttons[j]),`buttons overlap ${width}: ${layout.buttons[i].id}/${layout.buttons[j].id}`);
   if(width<=700)assert.ok(layout.hud.h+layout.tour.h<layout.shell.h*.21,`banners too large ${width}`);
   console.log(`${width}x${height}: banners ${Math.round((layout.hud.h+layout.tour.h)/layout.shell.h*100)}%, controls in bounds`);
   await page.screenshot({path:`test-results/layout-${width}.png`});
 }
 await page.emulateMedia({reducedMotion:'reduce'});await page.reload();await page.waitForFunction(()=>window.__drift);
 await page.locator('#mode-tour').click();await page.locator('#start').click();
 await page.evaluate(()=>{const {game:g,renderer:r}=window.__drift;g.distance=2075;g.objects=[];g._nextRow=Infinity;g._updateBoss(0);g.pause();r.reducedMotion=true;r.draw(g,0,0)});
 assert.equal(errors.length,0,errors.join('; '));console.log('No runtime errors; reduced-motion render passed');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
