const {chromium}=require('C:/Users/trist/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'msedge'});
 for(const test of ['ui','feature']) {
  const page=await browser.newPage({viewport:{width:1280,height:960}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(`http://127.0.0.1:5173/test/${test}-smoke.html`);
  try {await page.waitForFunction(()=>{const t=document.getElementById('status')?.textContent||'';return /passed|FAIL|failed/.test(t)},null,{timeout:45000});}
  catch{console.log(test,'timeout',await page.locator('body').innerText());throw Error(test+' did not complete');}
  const result=await page.locator('#status').innerText();console.log(test,result);
  if(/FAIL|failed/.test(result)||errors.length)throw Error(result+' '+errors.join('; '));
  await page.close();
 }
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
